//#region src/background/service-worker.ts
/**
* Background service worker (Manifest V3).
*
* Kept minimal per PRD guidance — complex logic lives in the
* content script, not here. This handles:
* - Extension icon click (opens Claude.ai if not already on it)
* - Future: storage access for settings
*/
chrome.action.onClicked.addListener(async (tab) => {
	if (tab.url && tab.url.includes("claude.ai")) {
		if (tab.id) try {
			await chrome.tabs.sendMessage(tab.id, { type: "OPEN_PANEL" });
		} catch {
			console.debug("[Capy] Content script not ready");
		}
	} else chrome.tabs.create({ url: "https://claude.ai" });
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
	if (message.type === "GET_SETTINGS") {
		chrome.storage.local.get([
			"selectedProvider",
			"apiKeys",
			"lastExportMode",
			"lastScope"
		], (result) => {
			sendResponse(result);
		});
		return true;
	}
	if (message.type === "SAVE_SETTINGS") {
		chrome.storage.local.set(message.data, () => {
			sendResponse({ success: true });
		});
		return true;
	}
	if (message.type === "FETCH_PROXY") {
		const { url, options } = message;
		fetch(url, options).then(async (res) => {
			const text = await res.text();
			sendResponse({
				success: true,
				status: res.status,
				text
			});
		}).catch((err) => {
			sendResponse({
				success: false,
				error: err.message
			});
		});
		return true;
	}
});
console.debug("[Capy] Service worker initialized");
//#endregion
