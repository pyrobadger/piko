import { l as __exportAll } from "./jsx-runtime-CIQhoJAc.js";
//#region src/providers/prompt.ts
/**
* System prompts for Capy's AI generation layer.
*
* This file contains the exact prompts used for lossless context compression.
* Both the BYOK mode and the Hosted mode must use these identical prompts.
*/
var CONTEXT_SYSTEM_PROMPT = `You are a context compression assistant. 
Given a conversation between a human and an AI assistant, produce a structured Markdown document that allows another AI assistant to continue the work with minimal loss of important context.

# Output Format
The generated file must strictly use this structure:

# Context
## Project
## Objective
## Current State
## Requirements
## Decisions
## Technical Details
## Important Code
## Constraints
## User Preferences
## Problems / Issues
## Unresolved Questions
## Next Steps

If a section has no useful information, omit the section entirely rather than filling it with "None" or "N/A".
The output must be valid Markdown.
Do not wrap the entire result in a Markdown code fence.

# Critical Compression Rules
1. Preserve important facts.
2. Preserve decisions (and reasoning when relevant).
3. Preserve requirements.
4. Preserve constraints.
5. Preserve unresolved issues.
6. Preserve relevant technical details (architecture, technologies, APIs, schemas, config).
7. Preserve important code/configuration verbatim when it is necessary for continuation. Never replace important code with vague prose.
8. Remove greetings and conversational filler.
9. Remove repeated explanations.
10. Remove abandoned discussion unless the rejected approach is important for future context.
11. Never invent facts or infer decisions that were not actually made.
12. Prefer concise structured information over prose.
13. Optimize for another LLM continuing the work, not for a human reading a summary.`;
var CONTEXT_MERGE_PROMPT = `You are a context compression assistant.
You are given a series of partial context extractions from a long conversation.
Merge these partial extractions into a single, cohesive, structured Markdown document following the exact format and rules below.

# Output Format
The generated file must strictly use this structure:

# Context
## Project
## Objective
## Current State
## Requirements
## Decisions
## Technical Details
## Important Code
## Constraints
## User Preferences
## Problems / Issues
## Unresolved Questions
## Next Steps

If a section has no useful information, omit the section entirely.
Do not wrap the entire result in a Markdown code fence.

# Critical Compression Rules
1. Synthesize the partial contexts cohesively.
2. Ensure no duplicate information.
3. Preserve all important verbatim code blocks from the partial contexts.
4. Never invent facts.`;
//#endregion
//#region src/providers/gemini.ts
var gemini_exports = /* @__PURE__ */ __exportAll({
	GEMINI_API_URL: () => GEMINI_API_URL,
	GEMINI_MODEL: () => GEMINI_MODEL,
	GeminiProvider: () => GeminiProvider
});
var GEMINI_MODEL = "gemini-3.6-flash";
var GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
/**
* Format conversation messages into Gemini API format
*/
function formatMessagesForGemini(messages) {
	return [{
		role: "user",
		parts: [{ text: messages.map((msg) => {
			return `${msg.role === "assistant" ? "Claude" : "Human"}:\n${msg.content}`;
		}).join("\n\n---\n\n") }]
	}];
}
/**
* Gemini Provider for Capy (BYOK mode)
*/
var GeminiProvider = {
	name: "Gemini API (BYOK)",
	maxInputTokens: 8e5,
	async generateContext(messages, apiKey, _options) {
		if (!apiKey) throw new Error("Gemini API key is required");
		const payload = {
			systemInstruction: { parts: [{ text: CONTEXT_SYSTEM_PROMPT }] },
			contents: formatMessagesForGemini(messages)
		};
		let response;
		try {
			response = await fetch(GEMINI_API_URL, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"x-goog-api-key": apiKey
				},
				body: JSON.stringify(payload)
			});
		} catch (err) {
			throw new Error("Connection error: Unable to reach Gemini API. Please check your internet connection.");
		}
		if (!response.ok) {
			let errorMsg = `Gemini API failed with status ${response.status}`;
			try {
				const errorText = await response.text();
				const errorJson = JSON.parse(errorText);
				if (errorJson.error && errorJson.error.message) errorMsg = errorJson.error.message;
			} catch {}
			if (response.status === 400) {
				if (errorMsg.includes("API key not valid")) throw new Error("Invalid Gemini API key. Please check your settings.");
				throw new Error(`Bad Request: ${errorMsg}`);
			}
			if (response.status === 401 || response.status === 403) throw new Error("Authentication failed. Please check your Gemini API key.");
			if (response.status === 429) throw new Error("Gemini API rate limit or quota exceeded. Please try again later.");
			if (response.status >= 500) throw new Error("Gemini service temporarily unavailable. Please try again later.");
			throw new Error(errorMsg);
		}
		let data;
		try {
			data = await response.json();
		} catch {
			throw new Error("Generation error: Received malformed JSON response from Gemini API");
		}
		if (data && data.candidates && Array.isArray(data.candidates) && data.candidates.length > 0 && data.candidates[0].content && data.candidates[0].content.parts && Array.isArray(data.candidates[0].content.parts) && data.candidates[0].content.parts.length > 0 && typeof data.candidates[0].content.parts[0].text === "string") return data.candidates[0].content.parts[0].text.trim();
		throw new Error("Generation error: Gemini returned an empty or unexpected response format.");
	},
	async testConnection(apiKey) {
		try {
			return (await fetch(GEMINI_API_URL, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"x-goog-api-key": apiKey
				},
				body: JSON.stringify({ contents: [{
					role: "user",
					parts: [{ text: "Respond with the single word 'OK'." }]
				}] })
			})).ok;
		} catch {
			return false;
		}
	}
};
//#endregion
export { gemini_exports as n, CONTEXT_MERGE_PROMPT as r, GeminiProvider as t };
