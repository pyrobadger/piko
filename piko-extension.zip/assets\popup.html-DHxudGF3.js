const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/gemini-CyLyu15t.js","assets/jsx-runtime-CIQhoJAc.js"])))=>i.map(i=>d[i]);
import { a as loadSettings, c as require_react, i as new_md_default, n as sparkles_default, o as saveSettings, r as mascot_idea_default, s as require_client, t as require_jsx_runtime, u as __toESM } from "./jsx-runtime-CIQhoJAc.js";
//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region \0vite/preload-helper.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
var import_jsx_runtime = require_jsx_runtime();
var scriptRel = "modulepreload";
var assetsURL = function(dep) {
	return "/" + dep;
};
var seen = {};
var __vitePreload = function preload(baseModule, deps, importerUrl) {
	let promise = Promise.resolve();
	if (deps && deps.length > 0) {
		const links = document.getElementsByTagName("link");
		const cspNonceMeta = document.querySelector("meta[property=csp-nonce]");
		const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
		function allSettled(promises) {
			return Promise.all(promises.map((p) => Promise.resolve(p).then((value) => ({
				status: "fulfilled",
				value
			}), (reason) => ({
				status: "rejected",
				reason
			}))));
		}
		function importMetaResolve(specifier) {
			if (import.meta.resolve) return import.meta.resolve(specifier);
			return new URL(
				specifier,
				/** #__KEEP__ */
				import.meta.url
			).href;
		}
		promise = allSettled(deps.map((dep) => {
			dep = assetsURL(dep, importerUrl);
			dep = importMetaResolve(dep);
			if (dep in seen) return;
			seen[dep] = true;
			const isCss = dep.endsWith(".css");
			for (let i = links.length - 1; i >= 0; i--) {
				const link = links[i];
				if (link.href === dep && (!isCss || link.rel === "stylesheet")) return;
			}
			const link = document.createElement("link");
			link.rel = isCss ? "stylesheet" : scriptRel;
			if (!isCss) link.as = "script";
			link.crossOrigin = "";
			link.href = dep;
			if (cspNonce) link.setAttribute("nonce", cspNonce);
			document.head.appendChild(link);
			if (isCss) return new Promise((res, rej) => {
				link.addEventListener("load", res);
				link.addEventListener("error", () => rej(/* @__PURE__ */ new Error(`Unable to preload CSS for ${dep}`)));
			});
		}));
	}
	function handlePreloadError(err) {
		const e = new Event("vite:preloadError", { cancelable: true });
		e.payload = err;
		window.dispatchEvent(e);
		if (!e.defaultPrevented) throw err;
	}
	return promise.then((res) => {
		for (const item of res || []) {
			if (item.status !== "rejected") continue;
			handlePreloadError(item.reason);
		}
		return baseModule().catch(handlePreloadError);
	});
};
//#endregion
//#region src/popup/Popup.tsx
var Popup = () => {
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const [showKey, setShowKey] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [statusMsg, setStatusMsg] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		loadSettings().then((settings) => {
			if (settings.geminiApiKey) setApiKey(settings.geminiApiKey);
		});
	}, []);
	const handleSave = (val) => {
		setApiKey(val);
		saveSettings({ geminiApiKey: val });
	};
	const handleTestKey = async () => {
		if (!apiKey) {
			setStatus("error");
			setStatusMsg("Please enter an API key first.");
			return;
		}
		setStatus("testing");
		setStatusMsg("Testing connection...");
		try {
			const { GeminiProvider } = await __vitePreload(async () => {
				const { GeminiProvider } = await import("./gemini-CyLyu15t.js").then((n) => n.n);
				return { GeminiProvider };
			}, __vite__mapDeps([0,1]));
			if (await GeminiProvider.testConnection(apiKey)) {
				setStatus("success");
				setStatusMsg("Connection successful!");
			} else throw new Error("Invalid API key or network error.");
		} catch (err) {
			setStatus("error");
			setStatusMsg(err instanceof Error ? err.message : "Connection failed");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "popup-container",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mascot_idea_default,
				className: "peeking-mascot-top",
				alt: ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: sparkles_default,
						className: "decor-sparkle top-left",
						alt: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "header-icon glow",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: new_md_default,
							width: "20",
							height: "20",
							style: { objectFit: "contain" },
							alt: ""
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Piko Settings" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "close-btn",
						onClick: () => window.close(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							width: "16",
							height: "16",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "18",
								y1: "6",
								x2: "6",
								y2: "18"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "6",
								y1: "6",
								x2: "18",
								y2: "18"
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "body",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "byok-label",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "18",
								height: "18",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "var(--accent)",
								strokeWidth: "2.5",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								className: "glow-svg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" })
							}), "Bring Your Own Key (BYOK)"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "desc",
							children: "Enter your Gemini API key to use the unlimited BYOK processing mode. This key is stored securely in your browser's local storage and is never sent to our servers."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "input-wrapper",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									className: "input-icon",
									width: "16",
									height: "16",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "var(--text-muted)",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "3",
										y: "11",
										width: "18",
										height: "11",
										rx: "2",
										ry: "2"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M7 11V7a5 5 0 0 1 10 0v4" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: showKey ? "text" : "password",
									className: "input",
									placeholder: "AIzaSy...",
									value: apiKey,
									onChange: (e) => handleSave(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "input-action",
									onClick: () => setShowKey(!showKey),
									title: showKey ? "Hide key" : "Show key",
									children: showKey ? "Hide" : "Show"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: sparkles_default,
									className: "decor-sparkle mid-right",
									alt: ""
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "actions",
							style: { position: "relative" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "btn btn-primary glow",
								onClick: handleTestKey,
								disabled: !apiKey || status === "testing",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									width: "16",
									height: "16",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 12.55a11 11 0 0 1 14.08 0" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M1.42 9a16 16 0 0 1 21.16 0" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8.53 16.11a6 6 0 0 1 6.95 0" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
											x1: "12",
											y1: "20",
											x2: "12.01",
											y2: "20"
										})
									]
								}), status === "testing" ? "Testing..." : "Test Connection"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: sparkles_default,
								className: "decor-sparkle bottom-right",
								alt: ""
							})]
						}),
						statusMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `status-msg ${status}`,
							children: statusMsg
						})
					]
				})
			})
		]
	});
};
//#endregion
//#region src/popup/main.tsx
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, {}) }));
//#endregion
