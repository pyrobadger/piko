import { a as loadSettings, c as require_react, i as new_md_default, n as sparkles_default, r as mascot_idea_default, s as require_client, t as require_jsx_runtime, u as __toESM } from "./jsx-runtime-CIQhoJAc.js";
import { r as CONTEXT_MERGE_PROMPT, t as GeminiProvider } from "./gemini-CyLyu15t.js";
//#region src/platforms/claude/selectors.ts
/**
* Claude.ai DOM Selectors
*
* ALL Claude-specific CSS selectors and DOM query strategies are isolated here.
* When Claude updates their UI, this is the ONLY file that should need changes.
*
* Strategy: We use a ranked approach — try the most reliable selector first,
* fall back to progressively less stable ones.
*/
/** Selector strategies for finding the main conversation container */
var CONVERSATION_CONTAINER_SELECTORS = [
	"[role=\"main\"]",
	"main",
	"[data-testid=\"conversation-turn-list\"]",
	"[data-testid=\"chat-messages\"]",
	".flex-1.overflow-y-auto",
	"div[class*=\"conversation\"]",
	"div[class*=\"chat\"]"
];
/** Selectors for extracting content within a message */
var CONTENT_SELECTORS = {
	/** Code blocks — these are the most important to preserve */
	codeBlock: [
		"pre code",
		"pre",
		"[data-testid=\"code-block\"]",
		".code-block"
	],
	/** Inline code */
	inlineCode: ["code:not(pre code)"],
	/** Artifact containers */
	artifact: [
		"[data-testid=\"artifact\"]",
		"[data-testid*=\"artifact\"]",
		".artifact-container"
	],
	/** Markdown-rendered content area */
	markdownContent: [
		".standard-markdown",
		".markdown-content",
		".prose",
		"[data-testid=\"message-content\"]",
		".font-claude-response",
		".font-user-message"
	]
};
/**
* Query the DOM with a ranked list of selectors, returning the first match.
*/
function queryFirst(selectors, root = document) {
	for (const selector of selectors) try {
		const el = root.querySelector(selector);
		if (el) return el;
	} catch {
		continue;
	}
	return null;
}
/**
* URL patterns that indicate a Claude.ai conversation page.
*/
var CLAUDE_CONVERSATION_URL_PATTERNS = [/^https:\/\/claude\.ai\/chat\/.+/, /^https:\/\/claude\.ai\/project\/.+\/chat\/.+/];
/**
* Check if the current URL is a Claude conversation page.
*/
function isClaudeConversationPage(url = window.location.href) {
	return CLAUDE_CONVERSATION_URL_PATTERNS.some((pattern) => pattern.test(url));
}
//#endregion
//#region src/platforms/claude/parser.ts
/**
* Parse the current page's DOM to extract conversation messages.
* Returns an empty array if parsing fails (caller should then try fallback).
*/
function parseConversationDOM() {
	try {
		const messages = tryStrategyTurnBased() || tryStrategyDeepScan() || [];
		if (messages.length > 0) console.debug(`[Capy] Parsed ${messages.length} messages from DOM`);
		else console.warn("[Capy] DOM parsing found 0 messages");
		return messages;
	} catch (err) {
		console.error("[Capy] DOM parsing failed:", err);
		return [];
	}
}
/**
* Extract the conversation title from the page.
*/
function parseConversationTitle() {
	const pageTitle = document.title;
	if (pageTitle && pageTitle.length > 0 && pageTitle.length < 200) {
		const cleaned = pageTitle.replace(/\s*[-–|]\s*Claude.*$/i, "").trim();
		if (cleaned.length > 0) return cleaned;
	}
}
function tryStrategyTurnBased() {
	for (const selector of [
		"[data-testid^=\"conversation-turn-\"]",
		"[data-testid=\"user-turn\"]",
		"[data-testid=\"assistant-turn\"]",
		"[role=\"article\"]",
		".group\\/turn",
		"[class*=\"ConversationTurn\"]",
		"[class*=\"conversation-turn\"]"
	]) try {
		const turns = document.querySelectorAll(selector);
		if (turns.length >= 2) return parseTurnElements(Array.from(turns));
	} catch {
		continue;
	}
	return null;
}
function parseTurnElements(turns) {
	const messages = [];
	for (let i = 0; i < turns.length; i++) {
		const turn = turns[i];
		const role = detectRoleFromTurn(turn, i);
		const content = extractContentRobust(turn);
		if (content.trim().length > 0) messages.push({
			id: `msg-${messages.length}`,
			role,
			content,
			index: messages.length,
			timestamp: extractTimestamp(turn)
		});
	}
	return messages;
}
function tryStrategyDeepScan() {
	const container = queryFirst(CONVERSATION_CONTAINER_SELECTORS) || document.querySelector("main") || document.querySelector("[role=\"main\"]");
	if (!container) return null;
	const messages = [];
	const allElements = container.querySelectorAll("*");
	const messageRegions = [];
	for (const el of Array.from(allElements)) {
		const role = identifyMessageElement(el);
		if (role) {
			const depth = getDepth(el, container);
			messageRegions.push({
				el,
				role,
				depth
			});
		}
	}
	if (messageRegions.length === 0) return tryStrategyDirectChildren(container);
	const filtered = removeOverlapping(messageRegions);
	for (const region of filtered) {
		const content = extractContentRobust(region.el);
		if (content.trim().length > 0) messages.push({
			id: `msg-${messages.length}`,
			role: region.role,
			content,
			index: messages.length,
			timestamp: extractTimestamp(region.el)
		});
	}
	return messages.length > 0 ? messages : null;
}
/**
* Check if an element looks like a message container and determine its role.
* Returns the role if it's a message element, or null if it's not.
*/
function identifyMessageElement(el) {
	const testId = (el.getAttribute("data-testid") || "").toLowerCase();
	const className = (typeof el.className === "string" ? el.className : "").toLowerCase();
	const ariaLabel = (el.getAttribute("aria-label") || "").toLowerCase();
	if (testId.includes("user-message") || testId.includes("human-message") || testId.includes("user-turn") || className.includes("user-message") || ariaLabel.includes("your message") || ariaLabel.includes("user message")) return "user";
	if (testId.includes("assistant-message") || testId.includes("ai-message") || testId.includes("assistant-turn") || testId.includes("bot-message") || className.includes("assistant-message") || className.includes("claude-message") || ariaLabel.includes("claude") || ariaLabel.includes("assistant")) return "assistant";
	return null;
}
/**
* Fallback: try direct children of the conversation container.
* Assumes alternating user/assistant pattern.
*/
function tryStrategyDirectChildren(container) {
	let scrollContainer = container;
	const scrollables = container.querySelectorAll("[style*=\"overflow\"], [class*=\"scroll\"], [class*=\"overflow\"]");
	if (scrollables.length > 0) scrollContainer = scrollables[scrollables.length - 1];
	const children = Array.from(scrollContainer.children).filter((child) => {
		return (child.textContent?.trim() || "").length > 3 && child.tagName.toLowerCase() !== "style" && child.tagName.toLowerCase() !== "script";
	});
	if (children.length < 2) return null;
	const messages = [];
	for (let i = 0; i < children.length; i++) {
		const child = children[i];
		const role = detectRoleFromTurn(child, i);
		const content = extractContentRobust(child);
		if (content.trim().length > 0) messages.push({
			id: `msg-${messages.length}`,
			role,
			content,
			index: messages.length,
			timestamp: extractTimestamp(child)
		});
	}
	return messages.length > 0 ? messages : null;
}
/**
* Detect the role of a conversation turn element.
*/
function detectRoleFromTurn(el, turnIndex) {
	const testId = (el.getAttribute("data-testid") || "").toLowerCase();
	if (testId.includes("user") || testId.includes("human")) return "user";
	if (testId.includes("assistant") || testId.includes("bot") || testId.includes("ai")) return "assistant";
	const className = (typeof el.className === "string" ? el.className : "").toLowerCase();
	if (className.includes("user") || className.includes("human")) return "user";
	if (className.includes("assistant") || className.includes("claude") || className.includes("bot")) return "assistant";
	const ariaLabel = (el.getAttribute("aria-label") || "").toLowerCase();
	if (ariaLabel.includes("you") || ariaLabel.includes("user") || ariaLabel.includes("human")) return "user";
	if (ariaLabel.includes("claude") || ariaLabel.includes("assistant")) return "assistant";
	const srOnly = el.querySelector(".sr-only");
	if (srOnly) {
		const srText = (srOnly.textContent || "").toLowerCase();
		if (srText.includes("you said") || srText.includes("human said")) return "user";
		if (srText.includes("claude responded") || srText.includes("assistant responded")) return "assistant";
	}
	if (el.querySelector("[data-testid*=\"user\"], [data-testid*=\"human\"], [aria-label*=\"You\"], [aria-label*=\"User\"], [aria-label*=\"Human\"]")) return "user";
	if (el.querySelector("[data-testid*=\"assistant\"], [data-testid*=\"claude\"], [data-testid*=\"bot\"], [aria-label*=\"Claude\"], [aria-label*=\"Assistant\"]")) return "assistant";
	const hasRenderedMarkdown = el.querySelector("pre, code, h1, h2, h3, ol, ul, table, blockquote");
	const textLength = (el.textContent || "").trim().length;
	if (hasRenderedMarkdown && textLength > 200) return "assistant";
	const firstTextNode = getFirstMeaningfulText(el);
	if (firstTextNode) {
		const lower = firstTextNode.toLowerCase().trim();
		if (lower === "you" || lower === "human" || lower === "user") return "user";
		if (lower === "claude" || lower === "assistant") return "assistant";
	}
	return turnIndex % 2 === 0 ? "user" : "assistant";
}
/**
* Get the first small text content in an element (likely a label like "You" or "Claude").
*/
function getFirstMeaningfulText(el) {
	return document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode: (node) => {
		const text = node.textContent?.trim() || "";
		if (text.length > 0 && text.length < 30) return NodeFilter.FILTER_ACCEPT;
		return NodeFilter.FILTER_SKIP;
	} }).nextNode()?.textContent?.trim() || null;
}
/**
* Extract content from an element, with multiple fallback strategies.
*/
function extractContentRobust(el) {
	let content = findContentAreas(el).map((area) => htmlToMarkdown(area)).join("\n\n");
	if (content.trim().length === 0) content = getCleanInnerText(el);
	content = removeRolePrefix(content);
	return content;
}
/**
* Find the actual content areas within a message container.
* Claude nests the actual message content inside several wrapper divs,
* and there may be multiple blocks if tools were used.
*/
function findContentAreas(el) {
	for (const selector of CONTENT_SELECTORS.markdownContent) try {
		const found = el.querySelectorAll(selector);
		if (found.length > 0) {
			const valid = Array.from(found).filter((f) => f.textContent && f.textContent.trim().length > 0);
			if (valid.length > 0) return valid;
		}
	} catch {
		continue;
	}
	const totalText = (el.textContent || "").trim().length;
	if (totalText === 0) return [el];
	let bestChild = el;
	let bestRatio = 0;
	const divs = el.querySelectorAll("div");
	for (const div of Array.from(divs)) {
		const ratio = (div.textContent || "").trim().length / totalText;
		const depth = getDepth(div, el);
		if (ratio > .7 && depth > 0) {
			if (depth > getDepth(bestChild, el) || ratio > bestRatio) {
				bestChild = div;
				bestRatio = ratio;
			}
		}
	}
	return [bestChild];
}
/**
* Get the text content of an element, cleaned up for use as message content.
* Uses innerText which respects CSS visibility and layout.
*/
function getCleanInnerText(el) {
	return (el.innerText || el.textContent || "").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\t/g, "  ").replace(/\n{3,}/g, "\n\n").trim();
}
/**
* Remove role label prefixes like "You\n" or "Claude\n" from content.
*/
function removeRolePrefix(content) {
	return content.replace(/^(You|Human|User|Claude|Assistant)\s*\n+/i, "").trim();
}
/**
* Convert an HTML element to Markdown text.
*/
function htmlToMarkdown(el) {
	const parts = [];
	function walk(node) {
		if (node.nodeType === Node.TEXT_NODE) {
			let text = node.textContent || "";
			text = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
			parts.push(text);
			return;
		}
		if (node.nodeType !== Node.ELEMENT_NODE) return;
		const element = node;
		const tag = element.tagName.toLowerCase();
		if (isUIChrome(element)) return;
		switch (tag) {
			case "pre": {
				const codeEl = element.querySelector("code");
				const code = codeEl ? codeEl.textContent : element.textContent;
				const lang = detectCodeLanguage(element);
				parts.push(`\n\n\`\`\`${lang}\n${code?.trim()}\n\`\`\`\n\n`);
				return;
			}
			case "code":
				if (element.parentElement?.tagName.toLowerCase() !== "pre") {
					parts.push(`\`${element.textContent}\``);
					return;
				}
				break;
			case "strong":
			case "b":
				parts.push("**");
				walkChildren(node);
				parts.push("**");
				return;
			case "em":
			case "i":
				parts.push("*");
				walkChildren(node);
				parts.push("*");
				return;
			case "a": {
				let href = (element.getAttribute("href") || "").trim();
				if (/^(?:javascript|data|vbscript):/i.test(href)) href = "#";
				parts.push("[");
				walkChildren(node);
				parts.push(`](${href})`);
				return;
			}
			case "h1":
				parts.push("\n\n# ");
				walkChildren(node);
				parts.push("\n\n");
				return;
			case "h2":
				parts.push("\n\n## ");
				walkChildren(node);
				parts.push("\n\n");
				return;
			case "h3":
				parts.push("\n\n### ");
				walkChildren(node);
				parts.push("\n\n");
				return;
			case "h4":
				parts.push("\n\n#### ");
				walkChildren(node);
				parts.push("\n\n");
				return;
			case "p":
				parts.push("\n\n");
				walkChildren(node);
				parts.push("\n\n");
				return;
			case "br":
				parts.push("\n");
				return;
			case "ul":
				parts.push("\n");
				for (const child of Array.from(node.childNodes)) if (child.tagName?.toLowerCase() === "li") {
					parts.push("\n- ");
					for (const liChild of Array.from(child.childNodes)) walk(liChild);
				}
				parts.push("\n");
				return;
			case "ol": {
				parts.push("\n");
				let idx = 1;
				for (const child of Array.from(node.childNodes)) if (child.tagName?.toLowerCase() === "li") {
					parts.push(`\n${idx}. `);
					for (const liChild of Array.from(child.childNodes)) walk(liChild);
					idx++;
				}
				parts.push("\n");
				return;
			}
			case "blockquote":
				parts.push("\n\n> ");
				walkChildren(node);
				parts.push("\n\n");
				return;
			case "hr":
				parts.push("\n\n---\n\n");
				return;
			case "table":
				parts.push("\n\n");
				element.querySelectorAll("tr").forEach((row, rowIdx) => {
					const cells = row.querySelectorAll("td, th");
					const cellTexts = Array.from(cells).map((c) => c.textContent?.trim() || "");
					parts.push("| " + cellTexts.join(" | ") + " |\n");
					if (rowIdx === 0) parts.push("| " + cellTexts.map(() => "---").join(" | ") + " |\n");
				});
				parts.push("\n");
				return;
			case "img": {
				const alt = element.getAttribute("alt") || "Image";
				parts.push(`[${alt}]`);
				return;
			}
		}
		walkChildren(node);
	}
	function walkChildren(node) {
		for (const child of Array.from(node.childNodes)) walk(child);
	}
	walk(el);
	return parts.join("").replace(/\n{3,}/g, "\n\n").trim();
}
/**
* Detect if an element is UI chrome that should be skipped.
* Be conservative — only skip things we're very sure are UI, not content.
*/
function isUIChrome(el) {
	const tag = el.tagName.toLowerCase();
	if (tag === "button" || tag === "svg" || tag === "path") return true;
	if (tag === "nav" || tag === "header" || tag === "footer") return true;
	const testId = el.getAttribute("data-testid") || "";
	if (testId.includes("copy") || testId.includes("action") || testId.includes("toolbar") || testId.includes("menu")) return true;
	const className = typeof el.className === "string" ? el.className : "";
	if (className.includes("copy-btn") || className.includes("toolbar") || className.includes("action-bar") || className.includes("sticky")) return true;
	return false;
}
/**
* Detect the programming language of a code block.
*/
function detectCodeLanguage(preOrCodeEl) {
	const codeEl = preOrCodeEl.tagName.toLowerCase() === "pre" ? preOrCodeEl.querySelector("code") : preOrCodeEl;
	if (!codeEl) return "";
	const langMatch = (codeEl.className || "").match(/(?:language-|lang-|hljs\s+)(\w+)/);
	if (langMatch) return langMatch[1];
	const dataLang = codeEl.getAttribute("data-language") || preOrCodeEl.getAttribute("data-language") || "";
	if (dataLang) return dataLang;
	return "";
}
/**
* Extract a timestamp from a message element.
*/
function extractTimestamp(el) {
	const timeEl = el.querySelector("time");
	if (timeEl) return timeEl.getAttribute("datetime") || timeEl.textContent?.trim() || void 0;
}
function getDepth(el, root) {
	let depth = 0;
	let current = el;
	while (current && current !== root) {
		depth++;
		current = current.parentElement;
	}
	return depth;
}
/**
* Remove overlapping message regions (keep the most specific).
*/
function removeOverlapping(regions) {
	const sorted = [...regions].sort((a, b) => {
		const pos = a.el.compareDocumentPosition(b.el);
		if (pos & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
		if (pos & Node.DOCUMENT_POSITION_PRECEDING) return 1;
		return 0;
	});
	const result = [];
	for (const region of sorted) {
		const isNested = result.some((r) => r.el.contains(region.el));
		const containsExisting = result.some((r) => region.el.contains(r.el));
		if (!isNested && !containsExisting) result.push(region);
		else if (containsExisting) {}
	}
	return result;
}
//#endregion
//#region src/platforms/claude/inject.ts
/**
* Claude.ai UI injection.
*
* the overlay panel into the Claude.ai page.
*/
var BUTTON_ID = "capy-export-btn";
var OVERLAY_ROOT_ID = "capy-overlay-root";
/**
* Inject the floating "Export Context" button into the page.
* Returns a cleanup function to remove it.
*/
function injectExportButton(onOpen) {
	if (!isClaudeConversationPage()) return () => {};
	if (document.getElementById(BUTTON_ID)) return () => {};
	if (!document.getElementById("cappy-button-script")) {
		const script = document.createElement("script");
		script.id = "cappy-button-script";
		script.type = "module";
		script.src = chrome.runtime.getURL("cappy-button.js");
		(document.head || document.documentElement).appendChild(script);
	}
	const wrapper = document.createElement("div");
	wrapper.innerHTML = `<cappy-button id="${BUTTON_ID}" size="120" color="claude" shape="nuage" follow-cursor="true" cycle-expressions="true" expression-interval="5"></cappy-button>`;
	const button = wrapper.firstChild;
	Object.assign(button.style, {
		position: "fixed",
		bottom: "24px",
		right: "24px",
		zIndex: "10000",
		cursor: "pointer",
		filter: "drop-shadow(0px 6px 16px rgba(0, 0, 0, 0.25)) drop-shadow(0px 2px 4px rgba(0, 0, 0, 0.12))",
		transition: "filter 0.2s ease"
	});
	button.addEventListener("mouseenter", () => {
		button.style.filter = "drop-shadow(0px 8px 24px rgba(0, 0, 0, 0.35)) drop-shadow(0px 4px 8px rgba(0, 0, 0, 0.15))";
	});
	button.addEventListener("mouseleave", () => {
		button.style.filter = "drop-shadow(0px 6px 16px rgba(0, 0, 0, 0.25)) drop-shadow(0px 2px 4px rgba(0, 0, 0, 0.12))";
	});
	button.addEventListener("click", onOpen);
	document.body.appendChild(button);
	return () => {
		button.removeEventListener("click", onOpen);
		button.remove();
	};
}
/**
* Create and return the overlay root container.
*/
function createOverlayRoot() {
	const existing = document.getElementById(OVERLAY_ROOT_ID);
	if (existing) existing.remove();
	const root = document.createElement("div");
	root.id = OVERLAY_ROOT_ID;
	document.body.appendChild(root);
	return root;
}
/**
* Remove the overlay root from the DOM.
*/
function removeOverlayRoot() {
	const root = document.getElementById(OVERLAY_ROOT_ID);
	if (root) root.remove();
	document.dispatchEvent(new CustomEvent("capy-panel-closed"));
}
//#endregion
//#region src/assets/bottom-cloud.png
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
var bottom_cloud_default = "/assets/bottom-cloud-DJrEk1Ji.png";
//#endregion
//#region src/assets/mascot-heart.png
var mascot_heart_default = "/assets/mascot-heart-Ceam1vN-.png";
//#endregion
//#region src/assets/mascot-sparkles.png
var mascot_sparkles_default = "/assets/mascot-sparkles-DQyvBDJY.png";
//#endregion
//#region src/core/conversation.ts
/**
* Apply an ExportScope to a Message[] to get the subset to export.
*/
function applyScope(messages, scope) {
	switch (scope.type) {
		case "entire": return messages;
		case "selected": return messages.filter((m) => scope.messageIds.has(m.id));
		case "range": return messages.filter((m) => m.index >= scope.startIndex && m.index <= scope.endIndex);
	}
}
//#endregion
//#region src/core/selection.ts
/**
* Create an initial selection state.
*/
function createInitialSelection(messageCount) {
	return {
		mode: "entire",
		selectedIds: /* @__PURE__ */ new Set(),
		rangeStart: 0,
		rangeEnd: Math.max(0, messageCount - 1)
	};
}
/**
* Convert the current SelectionState into an ExportScope.
*/
function toExportScope(state) {
	switch (state.mode) {
		case "entire": return { type: "entire" };
		case "selected": return {
			type: "selected",
			messageIds: new Set(state.selectedIds)
		};
		case "range": return {
			type: "range",
			startIndex: state.rangeStart,
			endIndex: state.rangeEnd
		};
	}
}
/**
* Toggle a message's selection status.
*/
function toggleMessage(state, messageId) {
	const newIds = new Set(state.selectedIds);
	if (newIds.has(messageId)) newIds.delete(messageId);
	else newIds.add(messageId);
	return {
		...state,
		selectedIds: newIds
	};
}
/**
* Select all messages.
*/
function selectAll(state, messages) {
	return {
		...state,
		selectedIds: new Set(messages.map((m) => m.id))
	};
}
/**
* Deselect all messages.
*/
function deselectAll(state) {
	return {
		...state,
		selectedIds: /* @__PURE__ */ new Set()
	};
}
/**
* Set the range for range mode.
*/
function setRange(state, start, end) {
	return {
		...state,
		rangeStart: Math.min(start, end),
		rangeEnd: Math.max(start, end)
	};
}
/**
* Set the scope mode.
*/
function setMode(state, mode) {
	return {
		...state,
		mode
	};
}
/**
* Get the count of messages that will be exported given the current state.
*/
function getSelectedCount(state, totalMessages) {
	switch (state.mode) {
		case "entire": return totalMessages;
		case "selected": return state.selectedIds.size;
		case "range": return state.rangeEnd - state.rangeStart + 1;
	}
}
//#endregion
//#region src/core/markdown.ts
var DEFAULT_OPTIONS = {
	includeHeader: true,
	includeSeparators: true
};
/**
* Generate a Markdown string from a Conversation.
*/
function generateMarkdown(conversation, options = {}) {
	const opts = {
		...DEFAULT_OPTIONS,
		...options
	};
	const parts = [];
	if (opts.includeHeader) parts.push(generateHeader(conversation));
	for (let i = 0; i < conversation.messages.length; i++) {
		const msg = conversation.messages[i];
		if (opts.includeSeparators && i > 0) parts.push("\n---\n");
		parts.push(formatMessage(msg));
	}
	return parts.join("\n").trim() + "\n";
}
/**
* Generate the metadata header block.
*/
function generateHeader(conversation) {
	const lines = [];
	if (conversation.title) {
		const cleanTitle = conversation.title.replace(/\n/g, " ").trim();
		lines.push(`# ${cleanTitle}`);
	} else lines.push("# Conversation Export");
	lines.push("");
	lines.push(`**Source:** ${conversation.sourceUrl}`);
	lines.push(`**Exported:** ${conversation.exportedAt}`);
	lines.push(`**Messages:** ${conversation.messages.length}`);
	lines.push("");
	lines.push("---");
	return lines.join("\n");
}
/**
* Format a single message as Markdown.
*/
function formatMessage(msg) {
	const roleLabel = msg.role === "user" ? "Human" : "Assistant";
	const lines = [];
	lines.push("");
	lines.push(`## ${roleLabel}`);
	if (msg.timestamp) lines.push(`*${msg.timestamp}*`);
	lines.push("");
	lines.push(msg.content);
	return lines.join("\n");
}
/**
* Generate a filename for the export.
*/
function generateFilename(conversation) {
	const date = new Date(conversation.exportedAt).toISOString().replace(/[:.]/g, "-").slice(0, 19);
	return `${conversation.title ? slugify(conversation.title) : "conversation"}_${date}.md`;
}
/**
* Convert a string to a URL/filename-safe slug.
*/
function slugify(text) {
	return text.toLowerCase().replace(/[^\w\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").slice(0, 50).replace(/^-+|-+$/g, "");
}
//#endregion
//#region src/core/context.ts
/**
* Very rough token estimation (characters / 4).
* We only use this to decide if we need to chunk the conversation.
*/
function estimateTokens(text) {
	return Math.ceil(text.length / 4);
}
/**
* Split messages into chunks that fit within the token threshold.
*/
function chunkMessages(messages, thresholdTokens) {
	const chunks = [];
	let currentChunk = [];
	let currentTokens = 0;
	for (const msg of messages) {
		const msgTokens = estimateTokens(`${msg.role}: ${msg.content}`);
		if (currentTokens + msgTokens > thresholdTokens && currentChunk.length > 0) {
			chunks.push(currentChunk);
			currentChunk = [];
			currentTokens = 0;
		}
		currentChunk.push(msg);
		currentTokens += msgTokens;
	}
	if (currentChunk.length > 0) chunks.push(currentChunk);
	return chunks;
}
/**
* The main context generation pipeline.
* Handles chunking for large conversations and delegates to the appropriate provider (BYOK vs Hosted).
*/
async function generateContextDocument(conversation, options) {
	const thresholdTokens = 8e5;
	options.onProgress?.("Analyzing conversation...");
	const chunks = chunkMessages(conversation.messages, thresholdTokens);
	if (chunks.length === 1) {
		options.onProgress?.("Building final document...");
		return await generateSingle(chunks[0], options);
	}
	options.onProgress?.(`Conversation too large. Splitting into ${chunks.length} chunks...`);
	const partialContexts = [];
	for (let i = 0; i < chunks.length; i++) {
		options.onProgress?.(`Compressing context chunk ${i + 1} of ${chunks.length}...`);
		const partial = await generateSingle(chunks[i], options);
		partialContexts.push(partial);
	}
	options.onProgress?.("Synthesizing final document...");
	const synthesisMessages = partialContexts.map((ctx, idx) => ({
		id: `chunk-${idx}`,
		role: "user",
		content: `PARTIAL CONTEXT ${idx + 1}:\n\n${ctx}`,
		index: idx
	}));
	synthesisMessages.push({
		id: "merge-instruction",
		role: "user",
		content: CONTEXT_MERGE_PROMPT,
		index: chunks.length
	});
	return await generateSingle(synthesisMessages, options);
}
/**
* Generate context for a single chunk of messages.
*/
async function generateSingle(messages, options) {
	if (options.mode === "byok") {
		if (!options.apiKey) throw new Error("Gemini API key is required for BYOK mode");
		return await GeminiProvider.generateContext(messages, options.apiKey, {});
	} else return await generateHostedContext(messages);
}
/**
* Proxy fetch through the background script to avoid Mixed Content (HTTPS -> HTTP) blocking.
*/
async function proxyFetch(url, options) {
	const result = await chrome.runtime.sendMessage({
		type: "FETCH_PROXY",
		url,
		options
	});
	if (!result.success) throw new Error(result.error);
	return {
		ok: result.status >= 200 && result.status < 300,
		status: result.status,
		text: async () => result.text,
		json: async () => JSON.parse(result.text)
	};
}
/**
* Call the Capy backend to generate the context using the hosted API key.
*/
async function generateHostedContext(messages) {
	const response = await proxyFetch("https://piko.quickpdfassistant.in/api/context/generate", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			conversation: messages,
			scope: "entire"
		})
	});
	if (!response.ok) {
		const errorText = await response.text();
		let errorMsg = `Backend Error (${response.status})`;
		try {
			const errorJson = JSON.parse(errorText);
			if (errorJson.error) errorMsg = errorJson.error;
		} catch {}
		if (response.status === 429) throw new Error("Daily Capy AI limit reached. Try again tomorrow or use your own Gemini API key.");
		throw new Error(`Hosted AI failed: ${errorMsg}`);
	}
	const data = await response.json();
	if (data.context) return data.context;
	throw new Error("Received malformed response from Capy backend");
}
/**
* Get remaining hosted quota from the backend.
*/
async function getHostedQuota() {
	const API_URL = "https://piko.quickpdfassistant.in/api/context/quota";
	try {
		const response = await proxyFetch(API_URL);
		if (!response.ok) return 0;
		const data = await response.json();
		return typeof data.remaining === "number" ? data.remaining : 0;
	} catch (err) {
		console.error("[Capy] Failed to fetch quota:", err);
		return 0;
	}
}
//#endregion
//#region src/ui/MessageSelector.tsx
/**
* MessageSelector component.
*
* Renders a scrollable list of message previews inside the overlay panel.
* Each message has a checkbox for selection, or the whole thing operates
* in range mode with start/end dropdowns.
*/
var import_jsx_runtime = require_jsx_runtime();
function truncate(text, maxLen) {
	const clean = text.replace(/\n/g, " ").replace(/\s+/g, " ").trim();
	if (clean.length <= maxLen) return clean;
	return clean.slice(0, maxLen) + "…";
}
var MessageSelector = ({ messages, mode, selectedIds, rangeStart, rangeEnd, onToggle, onSelectAll, onDeselectAll, onRangeStartChange, onRangeEndChange }) => {
	if (mode === "range") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "cp-range-selector",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "cp-range-select",
				value: rangeStart,
				onChange: (e) => onRangeStartChange(Number(e.target.value)),
				children: messages.map((msg) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: msg.index,
					children: [
						"#",
						msg.index + 1,
						" — ",
						msg.role === "user" ? "Human" : "Assistant",
						":",
						" ",
						truncate(msg.content, 40)
					]
				}, msg.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "cp-range-arrow",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					width: "16",
					height: "16",
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "12",
						y1: "5",
						x2: "12",
						y2: "19"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "19 12 12 19 5 12" })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "cp-range-select",
				value: rangeEnd,
				onChange: (e) => onRangeEndChange(Number(e.target.value)),
				children: messages.map((msg) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: msg.index,
					children: [
						"#",
						msg.index + 1,
						" — ",
						msg.role === "user" ? "Human" : "Assistant",
						":",
						" ",
						truncate(msg.content, 40)
					]
				}, msg.id))
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "cp-select-controls",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "cp-select-btn",
				onClick: onSelectAll,
				children: "Select all"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				style: { color: "var(--cp-text-muted)" },
				children: "·"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "cp-select-btn",
				onClick: onDeselectAll,
				children: "Deselect all"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				style: {
					marginLeft: "auto",
					fontSize: "12px",
					color: "var(--cp-text-muted)"
				},
				children: [
					selectedIds.size,
					" of ",
					messages.length,
					" selected"
				]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "cp-message-list",
		children: messages.map((msg) => {
			const isSelected = selectedIds.has(msg.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `cp-message-item ${isSelected ? "selected" : ""}`,
				onClick: () => onToggle(msg.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "cp-checkbox",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						className: "cp-checkbox-check",
						width: "12",
						height: "12",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "20 6 9 17 4 12" })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cp-message-meta",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `cp-message-role ${msg.role}`,
						children: msg.role === "user" ? "Human" : "Assistant"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cp-message-preview",
						children: truncate(msg.content, 100)
					})]
				})]
			}, msg.id);
		})
	})] });
};
//#endregion
//#region src/ui/ExportPanel.tsx
var getUrl = (path) => {
	if (path.startsWith("chrome-extension://")) return path;
	const p = path.startsWith("/") ? path.slice(1) : path;
	return chrome.runtime?.getURL ? chrome.runtime.getURL(p) : path;
};
var ExportPanel = ({ onClose, getMessages, getTitle, getSourceUrl }) => {
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [selection, setSelection] = (0, import_react.useState)(createInitialSelection(0));
	const [format, setFormat] = (0, import_react.useState)("raw-markdown");
	const [aiMode, setAiMode] = (0, import_react.useState)("hosted");
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [progressMsg, setProgressMsg] = (0, import_react.useState)("");
	const [errorMsg, setErrorMsg] = (0, import_react.useState)("");
	const [successAction, setSuccessAction] = (0, import_react.useState)("");
	const [hostedQuota, setHostedQuota] = (0, import_react.useState)(null);
	const [generatedText, setGeneratedText] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const msgs = getMessages();
		setMessages(msgs);
		setSelection(createInitialSelection(msgs.length));
		loadSettings().then((settings) => {
			if (settings.geminiApiKey) setApiKey(settings.geminiApiKey);
		});
		getHostedQuota().then((quota) => setHostedQuota(quota));
	}, [getMessages]);
	const selectedCount = getSelectedCount(selection, messages.length);
	const buildConversation = (0, import_react.useCallback)(() => {
		const scope = toExportScope(selection);
		const filtered = applyScope(messages, scope);
		if (filtered.length === 0) {
			setErrorMsg("No messages selected. Please select at least one message.");
			setStatus("error");
			return null;
		}
		return {
			messages: filtered,
			sourceUrl: getSourceUrl(),
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			title: getTitle()
		};
	}, [
		messages,
		selection,
		getSourceUrl,
		getTitle
	]);
	const processExport = async () => {
		const conversation = buildConversation();
		if (!conversation) return null;
		if (format === "raw-markdown") return generateMarkdown(conversation);
		if (aiMode === "byok" && !apiKey) throw new Error("Gemini API key is required for BYOK mode.");
		if (aiMode === "hosted" && hostedQuota === 0) throw new Error("Daily Piko AI limit reached. Try again tomorrow or use your own Gemini API key.");
		return await generateContextDocument(conversation, {
			mode: aiMode,
			apiKey,
			onProgress: setProgressMsg
		});
	};
	const handleDownload = async () => {
		setStatus("exporting");
		setProgressMsg("Generating export...");
		setErrorMsg("");
		try {
			const text = generatedText || await processExport();
			if (!text) return;
			if (!generatedText) setGeneratedText(text);
			const conversation = buildConversation();
			const filename = format === "optimized-context" ? conversation.title ? `${conversation.title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}-context.md` : "context.md" : generateFilename(conversation);
			const blob = new Blob([text], { type: "text/markdown;charset=utf-8" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = filename;
			a.style.display = "none";
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(url);
			setStatus("success");
			setSuccessAction("downloaded");
			if (format === "optimized-context" && aiMode === "hosted") getHostedQuota().then((q) => setHostedQuota(q));
		} catch (err) {
			console.error("[Capy] Export failed:", err);
			setErrorMsg(`Export failed: ${err instanceof Error ? err.message : "Unknown error"}`);
			setStatus("error");
		}
	};
	const handleCopy = async () => {
		setStatus("exporting");
		setProgressMsg("Generating export...");
		setErrorMsg("");
		try {
			const text = generatedText || await processExport();
			if (!text) return;
			if (!generatedText) setGeneratedText(text);
			await navigator.clipboard.writeText(text);
			setStatus("success");
			setSuccessAction("copied to clipboard");
			if (format === "optimized-context" && aiMode === "hosted") getHostedQuota().then((q) => setHostedQuota(q));
		} catch (err) {
			console.error("[Capy] Copy failed:", err);
			setErrorMsg(`Copy failed: ${err instanceof Error ? err.message : "Unknown error"}`);
			setStatus("error");
		}
	};
	const handleReset = (0, import_react.useCallback)(() => {
		setStatus("idle");
		setErrorMsg("");
		setSuccessAction("");
		setGeneratedText("");
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "cp-backdrop",
		onClick: onClose
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "cp-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cp-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cp-header-title",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cp-header-icon",
						style: {
							background: "transparent",
							width: "auto",
							height: "auto"
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: getUrl(mascot_sparkles_default),
							alt: "Cappy",
							width: "56"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Export Conversation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "cp-header-subtitle",
						children: "Save your chat, your way."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "cp-close-btn",
					onClick: onClose,
					title: "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						width: "20",
						height: "20",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "18",
							y1: "6",
							x2: "6",
							y2: "18"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "6",
							y1: "6",
							x2: "18",
							y2: "18"
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cp-body",
				children: status === "success" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cp-success",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "cp-success-icon",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "24",
								height: "24",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "20 6 9 17 4 12" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "cp-success-text",
							children: "Export complete!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "cp-success-detail",
							children: [format === "optimized-context" ? "Context generated and " : `${selectedCount} messages `, successAction]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "cp-btn cp-btn-secondary",
							onClick: handleReset,
							style: { marginTop: "8px" },
							children: "Export another"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								marginTop: "32px",
								padding: "16px",
								borderRadius: "12px",
								background: "var(--cp-bg-tertiary)",
								border: "1px solid var(--cp-border)",
								display: "flex",
								flexDirection: "column",
								alignItems: "center",
								gap: "12px",
								width: "100%",
								maxWidth: "280px",
								position: "relative",
								zIndex: 10
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: {
									fontSize: "13px",
									color: "var(--cp-text-secondary)",
									textAlign: "center",
									lineHeight: "1.4"
								},
								children: "Find Piko helpful? Consider supporting its development! ☕"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "https://buymeacoffee.com/pyrobadger",
								target: "_blank",
								rel: "noopener noreferrer",
								className: "cp-btn",
								style: {
									textDecoration: "none",
									width: "100%",
									background: "#FFDD00",
									color: "#000000",
									border: "none",
									fontWeight: 600
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									width: "18",
									height: "18",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2.5",
									style: { marginRight: "6px" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 8h1a4 4 0 0 1 0 8h-1" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
											x1: "6",
											y1: "1",
											x2: "6",
											y2: "4"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
											x1: "10",
											y1: "1",
											x2: "10",
											y2: "4"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
											x1: "14",
											y1: "1",
											x2: "14",
											y2: "4"
										})
									]
								}), "Buy me a coffee"]
							})]
						})
					]
				}) : status === "exporting" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cp-loading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cp-spinner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cp-loading-text",
						children: progressMsg
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					status === "error" && errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cp-error-box",
						children: errorMsg
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "cp-section",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "cp-section-label",
							children: "Output Format"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "cp-format-selector",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `cp-format-btn ${format === "raw-markdown" ? "active" : ""}`,
								onClick: () => setFormat("raw-markdown"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: getUrl(new_md_default),
									alt: "",
									width: "20",
									height: "20",
									style: { objectFit: "contain" }
								}), "Raw Markdown"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `cp-format-btn ${format === "optimized-context" ? "active" : ""}`,
								onClick: () => setFormat("optimized-context"),
								children: ["Optimized context.md", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: getUrl(sparkles_default),
									alt: "",
									width: "22",
									className: "cp-sparkle-sm",
									style: { marginLeft: "4px" }
								})]
							})]
						})]
					}),
					format === "optimized-context" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cp-section",
						style: { marginTop: "-8px" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "cp-ai-modes",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `cp-ai-mode-card ${aiMode === "hosted" ? "active" : ""}`,
								onClick: () => setAiMode("hosted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "cp-ai-mode-header",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⚡ Piko AI" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "cp-ai-mode-desc",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Uses Google's AI Models" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Files are temporarily uploaded to Piko's Google account. No logs are stored." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											style: { color: hostedQuota === 0 ? "var(--cp-error)" : "var(--cp-success)" },
											children: hostedQuota !== null ? `${hostedQuota} generation${hostedQuota === 1 ? "" : "s"} remaining today` : "Loading quota..."
										})
									] })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `cp-ai-mode-card ${aiMode === "byok" ? "active" : ""}`,
								onClick: () => setAiMode("byok"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "cp-ai-mode-header",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🔑 Use your own Gemini API" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "cp-ai-mode-desc",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stored locally on this device only" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your Files never leave you :)" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											style: { fontStyle: "italic" },
											children: "PS: Only Gemini API Keys are currently supported"
										})
									] }), aiMode === "byok" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "cp-input-group",
										style: {
											marginTop: "12px",
											color: "var(--cp-text-muted)"
										},
										children: apiKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "✅ API Key configured" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⚠️ Please click the Piko icon in your browser toolbar to set your API key." })
									})]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "cp-status-bar",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "cp-status-count",
							style: {
								display: "flex",
								alignItems: "center",
								gap: "8px"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: getUrl(mascot_heart_default),
								alt: "",
								width: "28",
								height: "28",
								style: { objectFit: "contain" }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: messages.length }), " messages found"] })]
						}), messages.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "cp-status-badge ready",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "12",
								height: "12",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "20 6 9 17 4 12" })
							}), "Ready"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "cp-status-badge error",
							children: "No messages"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "cp-section",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "cp-section-label",
							children: "Export Scope"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "cp-radio-group",
							children: [
								{
									value: "entire",
									label: "Entire conversation",
									hint: `${messages.length} msgs`
								},
								{
									value: "selected",
									label: "Selected messages",
									hint: "Pick specific"
								},
								{
									value: "range",
									label: "Range",
									hint: "From → To"
								}
							].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `cp-radio-option ${selection.mode === option.value ? "active" : ""}`,
								onClick: () => setSelection(setMode(selection, option.value)),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "cp-radio-circle",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cp-radio-dot" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "cp-radio-label",
										children: option.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "cp-radio-hint",
										children: option.hint
									})
								]
							}, option.value))
						})]
					}),
					(selection.mode === "selected" || selection.mode === "range") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "cp-section",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "cp-section-label",
							children: selection.mode === "selected" ? "Select Messages" : "Select Range"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSelector, {
							messages,
							mode: selection.mode,
							selectedIds: selection.selectedIds,
							rangeStart: selection.rangeStart,
							rangeEnd: selection.rangeEnd,
							onToggle: (id) => setSelection(toggleMessage(selection, id)),
							onSelectAll: () => setSelection(selectAll(selection, messages)),
							onDeselectAll: () => setSelection(deselectAll(selection)),
							onRangeStartChange: (idx) => setSelection(setRange(selection, idx, selection.rangeEnd)),
							onRangeEndChange: (idx) => setSelection(setRange(selection, selection.rangeStart, idx))
						})]
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cp-decorative-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: getUrl(bottom_cloud_default),
					className: "cp-cloud-bg",
					alt: ""
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: getUrl(mascot_idea_default),
				className: "cp-peeking-mascot",
				alt: ""
			}),
			status !== "success" && status !== "exporting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cp-footer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "cp-btn cp-btn-primary",
					onClick: handleDownload,
					disabled: messages.length === 0 || selection.mode === "selected" && selection.selectedIds.size === 0 || format === "optimized-context" && aiMode === "byok" && !apiKey,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "7 10 12 15 17 10" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "12",
								y1: "15",
								x2: "12",
								y2: "3"
							})
						]
					}), format === "optimized-context" ? "Generate & Download" : "Download .md"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "cp-btn cp-btn-secondary",
					onClick: handleCopy,
					disabled: messages.length === 0 || selection.mode === "selected" && selection.selectedIds.size === 0 || format === "optimized-context" && aiMode === "byok" && !apiKey,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "9",
							y: "9",
							width: "13",
							height: "13",
							rx: "2",
							ry: "2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })]
					}), "Copy"]
				})]
			})
		]
	})] });
};
//#endregion
//#region src/ui/OverlayApp.tsx
/**
* OverlayApp — Root component for the injected overlay panel.
*
* This is the mount/unmount entry point that the content script uses
* to render the React UI into the page.
*/
var root = null;
/**
* Mount the overlay panel React app into a DOM element.
*/
function mountOverlay(container, props) {
	if (root) unmountOverlay();
	root = (0, import_client.createRoot)(container);
	root.render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportPanel, {
		onClose: props.onClose,
		getMessages: props.getMessages,
		getTitle: props.getTitle,
		getSourceUrl: props.getSourceUrl
	}) }));
}
/**
* Unmount the overlay panel React app.
*/
function unmountOverlay() {
	if (root) {
		root.unmount();
		root = null;
	}
}
//#endregion
//#region src/content/content.ts
var CONTEXTPORT_MSG_TYPE = "CONTEXTPORT_INTERCEPTED_DATA";
/** Messages intercepted via the MAIN-world fetch hook (fallback data) */
var interceptedMessages = [];
/** Whether the overlay panel is currently open */
var panelOpen = false;
/**
* Listen for messages from the MAIN-world script.
*/
window.addEventListener("message", (event) => {
	if (event.source !== window) return;
	if (event.data?.type !== CONTEXTPORT_MSG_TYPE) return;
	const { messages } = event.data;
	if (Array.isArray(messages) && messages.length > 0) {
		interceptedMessages = messages.map((m, i) => ({
			id: `intercepted-${i}`,
			role: m.role === "user" ? "user" : "assistant",
			content: m.content,
			index: i
		}));
		console.debug(`[Capy] Intercepted ${interceptedMessages.length} messages from API`);
	}
});
/**
* Inject the MAIN-world script into the page.
*/
function injectMainWorldScript() {
	try {
		const script = document.createElement("script");
		script.src = chrome.runtime.getURL("src/content/main-world.ts");
		script.type = "module";
		(document.head || document.documentElement).appendChild(script);
		script.onload = () => script.remove();
	} catch (err) {
		console.warn("[Capy] Failed to inject main-world script:", err);
	}
}
/**
* Get the conversation messages using DOM parsing first, then fallback.
*/
function getConversationMessages() {
	const domMessages = parseConversationDOM();
	if (domMessages.length > 0) {
		console.debug(`[Capy] Parsed ${domMessages.length} messages from DOM`);
		return domMessages;
	}
	if (interceptedMessages.length > 0) {
		console.debug(`[Capy] Using ${interceptedMessages.length} intercepted messages (DOM parse failed)`);
		return interceptedMessages;
	}
	console.warn("[Capy] No messages found via DOM or interception");
	return [];
}
/**
* Get the conversation title.
*/
function getConversationTitle() {
	return parseConversationTitle();
}
function openPanel() {
	if (panelOpen) return;
	panelOpen = true;
	mountOverlay(createOverlayRoot(), {
		onClose: closePanel,
		getMessages: getConversationMessages,
		getTitle: getConversationTitle,
		getSourceUrl: () => window.location.href
	});
}
function closePanel() {
	if (!panelOpen) return;
	panelOpen = false;
	unmountOverlay();
	removeOverlayRoot();
}
function init() {
	if (!isClaudeConversationPage()) {
		observeUrlChanges();
		return;
	}
	console.debug("[Capy] Initializing on conversation page");
	injectMainWorldScript();
	injectExportButton(openPanel);
}
/**
* Watch for SPA-style navigation (Claude is a single-page app).
* Re-initialize when the user navigates to/from a conversation.
*/
function observeUrlChanges() {
	let lastUrl = window.location.href;
	let cleanupButton = null;
	new MutationObserver(() => {
		if (window.location.href !== lastUrl) {
			lastUrl = window.location.href;
			if (cleanupButton) {
				cleanupButton();
				cleanupButton = null;
			}
			if (panelOpen) closePanel();
			if (isClaudeConversationPage()) {
				injectMainWorldScript();
				cleanupButton = injectExportButton(openPanel);
			}
		}
	}).observe(document.body, {
		childList: true,
		subtree: true
	});
}
chrome.runtime.onMessage.addListener((message) => {
	if (message.type === "OPEN_PANEL") {
		if (isClaudeConversationPage()) openPanel();
	}
});
init();
setTimeout(() => {
	if (isClaudeConversationPage() && !document.getElementById("capy-export-btn")) injectExportButton(openPanel);
}, 2e3);
//#endregion
export { getConversationMessages, getConversationTitle };
